package Bai6_6;
abstract public  class Animal {
    private String name;
    public Animal(String name){
        this.name = name;

    }
    public void greets(){

    }
}

