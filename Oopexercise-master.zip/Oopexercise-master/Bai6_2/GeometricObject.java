package Bai6_2;
public interface GeometricObject {
    public double getArea();
    public double getPerimeter();

}

