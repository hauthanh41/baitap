package Bai6_5;

public interface GeometricObject {
    public double getArea();
    public double getPerimeter();

}

