package Bai6_5;
public  interface Resizeable {
    public void resize(int percent);

}

